<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index()
    {
        $q = [
					'isi'=>"dashboard",
				];
        return view('layout/home',$q);
    }
}
