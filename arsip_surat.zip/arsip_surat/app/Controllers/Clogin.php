<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\Mlogin;

class Clogin extends BaseController
{
	public function index()
	{
		echo view("login");
	}
	public function dashboard()
	{
		$q = [
			'isi' => "dashboard",
			'menu' => "dashboard",
		];
		echo view("layout/home", $q);
	}
	public function Ceklog()
	{
		$Mlog = new Mlogin;
		$user = $this->request->getPost("user");
		$pass = $this->request->getPost("pass");
		$cek 	= $Mlog->Ceklog($user, $pass);
		if ($cek->getNumRows() > 0) {
			$admin = $cek->getRowArray();
			$ses_admin = [
				'nama' => $admin['nama_ad'],
				'level' => $admin['level'],
			];
			session()->set($ses_admin);
			$q = [
				'isi' => "dashboard",
				'menu' => "dashboard",
			];
			echo view('layout/home', $q);
		} else {

			echo "gagal";
		}
	}
}
