<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\Mkategori;


class Ckategori extends BaseController
{
  public function ProEditKategori()
  {
    $k = new Mkategori;
    $id         = $this->request->getPost('id');
    $kategori   = $this->request->getPost('kategori');
    $tgl_update = $this->request->getPost('tgl_update');
    $cek = $k->CekInput($kategori);
    if ($cek->getNumRows() > 0) {
      $q = [
        'kategori' => $k->Tampil(),
        'isi' => "kategori/tampil",
        'menu' => "kategori"
      ];
      session()->setFlashdata('psn', "gagal");
      echo view("layout/home", $q);
    } else {
      $update = [
        'nama_kategori' => $kategori,
        'update_kategori' => $tgl_update
      ];
      $k->ProEditKategori($update, $id);
      $q = [
        'kategori' => $k->Tampil(),
        'isi' => "kategori/tampil",
        'menu' => "kategori"
      ];
      session()->setFlashdata('psn', "berhasil");
      echo view("layout/home", $q);
    }
  }
  public function ProTambahKategori()
  {
    $k          = new Mkategori;
    $id         = $this->request->getPost('id');
    $kategori   = $this->request->getPost('kategori');
    $tgl_input  = $this->request->getPost('tgl_input');
    $cek = $k->CekInput($kategori);
    if ($cek->getNumRows() > 0) {
      $q = [
        'kategori' => $k->Tampil(),
        'isi' => "kategori/tampil",
        'menu' => "kategori"
      ];
      session()->setFlashdata('psn', "gagal");
      echo view("layout/home", $q);
    } else {
      $input = [
        'id_kategori' => $id,
        'nama_kategori' => $kategori,
        'input_kategori' => $tgl_input
      ];
      $k->ProTambahKategori($input);
      $q = [
        'kategori' => $k->Tampil(),
        'isi' => "kategori/tampil",
        'menu' => "kategori"
      ];
      session()->setFlashdata('psn', "berhasil");
      echo view("layout/home", $q);
    }
  }
  public function Tampil()
  {
    $k = new Mkategori;
    $q = [
      'kategori' => $k->Tampil(),
      'isi' => "kategori/tampil",
      'menu' => "kategori"
    ];
    echo view("layout/home", $q);
  }
}
