<?php 
echo view('layout/header');
echo view('layout/navbar');
echo view($isi);
echo view('layout/footer');
?>