    <!-- Required Js -->
    <script src="<?= base_url() ?>/assets/js/vendor-all.min.js"></script>
    <script src="<?= base_url() ?>/assets/js/plugins/bootstrap.min.js"></script>
    <!-- <script src="<?= base_url() ?>/assets/js/ripple.js"></script> -->
    <script src="<?= base_url() ?>/assets/js/pcoded.min.js"></script>

    </body>
    <script>
        $(document).ready(function() {
            $('.data').DataTable();
        });
    </script>
    <script>
        new DataTable('#data', {
            info: true,
            ordering: true,
            paging: true
        });
    </script>

    </html>