<!-- [ Main Content ] start -->
<div class="pcoded-main-container">
  <div class="pcoded-content">
    <!-- [ breadcrumb ] start -->
    <div class="page-header">
      <div class="page-block">
        <div class="row align-items-center">
          <div class="col-md-12">
            <ul class="breadcrumb">
              <li class="breadcrumb-item"><a href="<?php echo base_url('Clogin/index') ?>"><i class="feather icon-home"></i></a></li>
              <li class="breadcrumb-item"><a href="#!">Kategori</a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <!-- [ breadcrumb ] end -->
    <!-- [ Main Content ] start -->
    <div class="row">
      <!-- [ sample-page ] start -->
      <div class="col-sm-12">
        <div class="card">

          <div class="card-header">
            <h5>Data Kategori Surat</h5>
            <div class="card-header-right">
              <div class="btn-group card-option">
                <button type="button" class="btn dropdown-toggle btn-icon" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <i class="feather icon-more-horizontal"></i>
                </button>
                <ul class="list-unstyled card-option dropdown-menu dropdown-menu-right">
                  <li class="dropdown-item full-card"><a href="#!"><span><i class="feather icon-maximize"></i> maximize</span><span style="display:none"><i class="feather icon-minimize"></i> Restore</span></a></li>
                  <li class="dropdown-item minimize-card"><a href="#!"><span><i class="feather icon-minus"></i> collapse</span><span style="display:none"><i class="feather icon-plus"></i> expand</span></a></li>
                  <li class="dropdown-item reload-card"><a href="#!"><i class="feather icon-refresh-cw"></i> reload</a></li>
                </ul>
              </div>
            </div>
          </div>
          <div class="card-body">
            <button class="btn btn-primary btn-sm mb-3 has-ripple" data-toggle="modal" data-target="#tambahKategori"><i class="feather icon-plus"></i> Tambah</button>
            <table class="table data" id="data">
              <thead>
                <tr>
                  <th>Nomor</th>
                  <th>Kategori</th>
                  <th>Opsi</th>
                </tr>
              </thead>
              <tbody>
                <?php $no = 1;
                foreach ($kategori as $a) { ?>
                  <tr>
                    <td><?php echo $no++; ?></td>
                    <td><?php echo $a->nama_kategori ?></td>
                    <td class="justify-content-between">
                      <button class="btn btn-sm btn-info btn-round" data-toggle="modal" data-target="#detail<?php echo $a->id_kategori ?>"><i class="feather icon-search"> Detail</i></button>
                      <button class="btn btn-sm btn-success btn-round" data-toggle="modal" data-target="#edit<?php echo $a->id_kategori ?>"><i class="feather icon-edit"> Edit</i></button>
                    </td>
                  </tr>
                  <!-- Modal -->
                  <div class="modal fade" id="detail<?php echo $a->id_kategori ?>" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title">Detail Kategori Surat</h5>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                        <div class="modal-body">
                          <dl class="dl-horizontal row">
                            <dt class="col-sm-6">Kategori</dt>
                            <dd class="col-sm-6"><?php echo $a->nama_kategori ?></dd>
                            <dt class="col-sm-6">Tanggal Input</dt>
                            <dd class="col-sm-6"><?php echo $a->input_kategori ?></dd>
                            <dt class="col-sm-6">Tanggal Update</dt>
                            <dd class="col-sm-6"><?php echo $a->update_kategori ?></dd>
                          </dl>
                        </div>
                        <div class="modal-footer justify-content-between">
                          <button type="button" class="btn btn-danger btn-sm ml-3 mt-3 mb-3" data-dismiss="modal"><i class="feather icon-x"></i> Batal</button>
                          <button type="submit" class="btn btn-primary btn-sm mr-3"><i class="feather icon-save"></i> Simpan</button>
                        </div>
                        </form>
                      </div>
                    </div>
                  </div>
                  <!--modal end-->
                  <!-- Modal -->
                  <div class="modal fade" id="edit<?php echo $a->id_kategori ?>" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title">Edit Kategori Surat</h5>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                        <div class="modal-body">
                          <form action="<?php echo base_url('Ckategori/ProEditKategori') ?>" method="post">
                            <div class="form-group fill">
                              <label class="floating-label" for="Kategori">Kategori Surat</label>
                              <input type="text" class="form-control" aria-describedby="emailHelp" placeholder="Kategori Surat" autofocus required name="kategori" value="<?php echo $a->nama_kategori ?>">
                            </div>
                            <input type="hidden" name="tgl_update" value="<?php echo date('Y-m-d H:i:s') ?>">
                            <input type="hidden" name="id" value="<?php echo $a->id_kategori ?>>">
                        </div>
                        <div class="modal-footer justify-content-between">
                          <button type="button" class="btn btn-danger btn-sm ml-3 mt-3 mb-3" data-dismiss="modal"><i class="feather icon-x"></i> Batal</button>
                          <button type="submit" class="btn btn-primary btn-sm mr-3"><i class="feather icon-save"></i> Simpan</button>
                        </div>
                        </form>
                      </div>
                    </div>
                  </div>
                  <!--modal end-->
                <?php } ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <!-- [ sample-page ] end -->
    </div>
    <!-- [ Main Content ] end -->
  </div>
</div>
<!-- [ Main Content ] end -->


<!-- Modal -->
<div class="modal fade" id="tambahKategori" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Tambah Kategori Surat</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="<?php echo base_url('Ckategori/ProTambahKategori') ?>" method="post">
          <div class="form-group fill">
            <label class="floating-label" for="Kategori">Kategori Surat</label>
            <input type="text" class="form-control" aria-describedby="emailHelp" placeholder="Kategori Surat" autofocus required name="kategori">
          </div>
          <input type="hidden" name="tgl_input" value="<?php echo date('Y-m-d H:i:s') ?>">
          <input type="hidden" name="id" value="<?php echo random_string('alnum', 5) ?>">
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-danger btn-sm ml-3 mt-3 mb-3" data-dismiss="modal"><i class="feather icon-x"></i> Batal</button>
        <button type="submit" class="btn btn-primary btn-sm mr-3"><i class="feather icon-save"></i> Simpan</button>
      </div>
      </form>
    </div>
  </div>
</div>

<?php if (session()->getFlashdata('psn') == "gagal") { ?>
  <script>
    Swal.fire({
      icon: 'error',
      title: 'error',
      text: 'Data Sudah Ada',
      //footer: '<a href="">Why do I have this issue?</a>'
    });
  </script>
<?php } ?>
<?php if (session()->getFlashdata('psn') == "berhasil") { ?>
  <script>
    Swal.fire({
      icon: 'success',
      title: 'Berhasil',
      text: 'Proses Berhasil',
      //footer: '<a href="">Why do I have this issue?</a>'
    });
  </script>
<?php } ?>