<?php

namespace App\Models;

use CodeIgniter\Model;

class Mkategori extends Model
{
	public function ProEditKategori($update, $id)
	{
		return $this->db->table('kategori')->where(['id_kategori' => $id])->update($update);
	}
	public function ProTambahKategori($input)
	{
		return $this->db->table('kategori')->insert($input);
	}
	public function cekInput($kategori)
	{
		return $this->db->table('kategori')
			->where(['nama_kategori' => $kategori])
			->get();
	}
	public function Tampil()
	{
		return $this->db->table('kategori')->get()->getResult();
	}
}
