<?php

namespace App\Models;

use CodeIgniter\Model;

class Mlogin extends Model
{
	public function Ceklog($user, $pass)
	{
		return $this->db->table('admin')->getWhere(['username' => $user, 'password' => $pass]);
	}
}
